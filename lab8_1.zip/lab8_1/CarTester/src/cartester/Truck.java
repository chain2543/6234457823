/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartester;

/**
 *
 * @author ADMIN
 */
public class Truck extends Car{
    private double M_weight;
    private double weight;
    public Truck(double gas, double efficiency, double w, double maxw) {
        super(gas, efficiency);
        M_weight = maxw;
        if (w > M_weight) {
            weight = M_weight;
        }
        else {
            this.weight = weight;
        }
    }
    @Override
    public void drive(double dis) {
        double morefuel;
        if (weight < 1) {
            morefuel = 0;
        }
        else if (weight <= 10) {
            morefuel = 0.1;
        }
        else if (weight <= 20) {
            morefuel = 0.2;
        }
        else {
            morefuel = 0.3;
        }
        
        double distance = (1 - morefuel)*this.getGas()*this.getEfficiency();
        if (distance >= dis) {
            this.setGas(this.getGas() - (1 + morefuel)*(dis/this.getEfficiency()));
        }
        else {
            System.out.println("You cannot drive too far, please add gas");
        }
    }
}
