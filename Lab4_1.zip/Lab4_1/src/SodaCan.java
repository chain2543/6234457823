/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usci
 */
public class SodaCan {
    private double h;
    private double d;
    /**
     * @param args the command line arguments
     */
    SodaCan(double high,double midline){
        h = high;
        d = midline;
    }
    public double getVolume(){
        return (Math.PI)*(d/2)*(d/2)*h;
    }
    public double getSurfaceArea(){
        return ((Math.PI)*(d/2)*(d/2)*2)+(h*(Math.PI)*(d));
    }
    
}
