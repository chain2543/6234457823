/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
/**
 *
 * @author usci
 * 
 */public class SodaTester {
    
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);    
        System.out.print("Enter height: ");
        double h = sc.nextDouble();
        System.out.print("Enter diameter: ");
        double d = sc.nextDouble();
        SodaCan so = new SodaCan(h,d);
        System.out.println("Volume: " + so.getVolume());
        System.out.println("Surface area: " + so.getSurfaceArea());
    }
}
