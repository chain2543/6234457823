/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usci
 */
public class DigitExtractor {
    private int num;
    private int n;
    public DigitExtractor(int anInteger) {
        num = anInteger;
        n = num%10;
    }
    // คืนเลขหลักถัดไปที่ต้องการแยกออกมา
    public int nextDigit() {
        int nu = n;
        num = (num-n)/10;
        n=num%10;
        return nu;
    }
    
}
