/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ADMIN
 */
public class Secretary extends Employee implements Evaluation{
    private int typingSpeed;
    private int[] score;
    
    public Secretary(String name,int salary, int[] s, int typS){
        super(name,salary);
        score=s;
        typingSpeed=typS;
    
    }
    @Override
    public double evaluate() {
        double sum = 0;
        for(int i : score){
            sum += i;
        }
        return sum;
    }

    @Override
    public char grade(double point) {
        if(point>=90){
            this.setSalary(18000);
            return 'P'; 
        }
        else{
            return 'F';
        }
         
    }
}
