/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5;

/**
 *
 * @author ADMIN
 */
public class Zeller {
    public enum Day {
    Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday
};
    private int dayOfMonth; //เก็บวันของเดือน
    private int month; //เก็บเดือน
    private int year; //เก็บป
    private int h;
    private Day day;
    Zeller(int y,int m,int d){
        year = y;
        month = m;
        dayOfMonth = d;
        int q = d;
        if(m<3){m=m+12;};
        int j = y/100;
        int k = y%100;
        h=(q+(26*(m+1)/10)+k+k/4+j/4+5*j)%7;
    }
    public void getDayOfWeek(){
        switch(h){
            case 0:
                System.out.println("Day of the week is Saturday");
                break;                    
            case 1:
                System.out.println("Day of the week is Sunday");
                break;                         
            case 2: 
                System.out.println("Day of the week is Monday");
                break;
            case 3:            
                System.out.println("Day of the week is Tuesday");
                break;
            case 4: 
                System.out.println("Day of the week is Wednesday");
                break;
            case 5: 
                System.out.println("Day of the week is Thursday");
                break;
            case 6: 
                System.out.println("Day of the week is Friday");
                break;    
        }
    }
}
