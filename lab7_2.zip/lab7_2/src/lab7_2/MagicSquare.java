/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_2;
import java.util.ArrayList;
/**
 *
 * @author ADMIN
 */
public class MagicSquare {
    private ArrayList<Integer> num;
    private int[][] table; 
    private int i;
    private int j;
    private int tableSize;
    private final boolean check;
    
    public MagicSquare(int n) {
        
        if (n%2==0||n<1) {
            check = false;
            System.out.println("Invalid input: odd number only");
        }
        else {
            check = true;
            tableSize = n-1;
            num = new ArrayList<Integer>();
            for (int i = 1; i <= n*n; i++) {
                num.add(i);  
            }

            table = new int[n][n];
            i = n-1;
            j = n/2;
            table[i][j] = num.get(0);
            num.remove(0);

            for (int num : num) {
                
                if (i+1 > tableSize || j+1 > tableSize) {
                    if (i+1 > tableSize && j+1 <= tableSize) {
                        i = 0;
                        j++;
                    }
                    else if (j+1 > tableSize && i+1 <= tableSize) {
                        j = 0;
                        i++;
                    }
                    else if (i+1 > tableSize && j+1 > tableSize) {
                        i--;
                    }
                }
                
                else {
                    if (table[i+1][j+1] == 0) {
                        i++;
                        j++;
                    }
                    else {
                        i--;
                    }
                }
                table[i][j] = num;
            }
        }
    }
    
    @Override
    public String toString() {
        String magicSquareString = "";
        if (check) {
            int lineCount = 0;
            for (int[] i : table) {
                for (int j : i) {
                    magicSquareString = magicSquareString + j;
                    lineCount++;
                    if (lineCount == table.length) {
                        magicSquareString = magicSquareString + "\n";
                        lineCount = 0;
                    }
                    else {
                        if (j >= 10) {
                            magicSquareString = magicSquareString + " ";
                        }
                        else {
                            magicSquareString = magicSquareString + "  ";
                        }
                    }
                }
            }
        }
        return magicSquareString;
    }
}
