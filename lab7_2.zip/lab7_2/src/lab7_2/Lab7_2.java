/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_2;

/**
 *
 * @author ADMIN
 */
public class Lab7_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        for (int i = -1; i < 10; i++) {
            System.out.println("If you enter "+i);
            MagicSquare sq = new MagicSquare(i);
            System.out.println(sq.toString());
        }
    }
    
}
