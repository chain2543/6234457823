
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ADMIN
 */
public class BusTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Bus> arr = new ArrayList<>();
        Hybrid hbus = new Hybrid(45,1.2E6,Electric.HIGHT_VOLTAGE ,150,1);
        CNGBus cbus = new CNGBus(50, 1E6, 200, 2);
        arr.add(hbus);
        arr.add(cbus);
        
        for (Bus bus : arr){
            System.out.println("ID : " + bus.getID());
            if(bus instanceof CNGBus){
                 System.out.println("Emission Tier : " + ((CNGBus)bus).getEmissionTier());
            }
            else if(bus instanceof Hybrid){
                 System.out.println("Emission Tier : " + ((Hybrid)bus).getEmissionTier());
            }
            System.out.println("Accel : " + bus.getAccel());
           
          }
        // TODO code application logic here
    }
    
}
