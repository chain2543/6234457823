/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ADMIN
 */
public class PizzaSpecial extends Pizza{
    private String special;

    public PizzaSpecial(String name, int price,String s) {
        super(name, price);
        special = s;
    }
    @Override
    public String toString(){
        return super.toString()+" special : "+special;
    }
}
