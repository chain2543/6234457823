/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author asus
 */
public class TimeInterval {
    private int start=0,end=0,dif=0;
    TimeInterval(int sta,int sto){
        start = sta;
        end = sto;
        dif = end-start;
    }
    public String getHours(){
        int h = dif/100;
        return (h+" hours ");
    }
    public String getMinutes(){
        int m1 = start%100;
        int m2 = end%100;
        int m;
        if(m1>m2){
            m = (m2+60)-m1;
        }
        else{
            m = m2-m1;
        }
        return (m+" minutes ");
    }
}
