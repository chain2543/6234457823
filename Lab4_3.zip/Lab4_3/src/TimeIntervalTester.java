
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author asus
 */
public class TimeIntervalTester {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sca = new Scanner(System.in);
        System.out.print("Enter start time: ");
        int start = sca.nextInt();
        System.out.print("Enter end time: ");
        int end = sca.nextInt();
        TimeInterval ti = new TimeInterval(start,end);
        System.out.println(ti.getHours()+ti.getMinutes());
    }
}