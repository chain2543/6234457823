/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_2;
//import static java.lang.Double.NaN;
/**
 *
 * @author ADMIN
 */
public class Line {
    public double X = -99999;
    public double Y = -99999;
    //private double IY;
    public double M;
    public double IP;
    //private double IX;
    public Line(double x, double y, double m){
        X=x;
        Y=y;
        M=m;
        IP=y-m*x;
    }
    public Line(double x1, double y1, double x2, double y2){
        M=(y2-y1)/(x2-x1);
        IP=y1-M*x1;
    }
    public Line(double m, double b){
        M=m;
        IP=b;
        Y=b;
    }
    public Line(double a){
        X=a;
        
    }
    public boolean isParallel(Line line){
        return line.M == M;
    }
    public boolean equals(Line line){
        return (line.M==M)&&(line.IP==IP);
    }
    public boolean isIntersect(Line line){
        return line.M != M;
    }
    public void/*Point2D.Double*/ getIntersectionPoint(Line line){
        double IX;
        double IY;
        //if((line.M==M)==(line.IP==IP)){
        //   System.out.printf("Point of intersection: infinity,infinity\n");    
        //}
        //else if(line.M == M){}
        //else{
        if((X==-99999)&&(line.X==-99999)){
             IX =(line.IP-IP)/(M-line.M);
             IY =M*IX+IP;
        }
        else if(X==-99999){
            IX = line.X;
            IY =M*IX+IP;
        }
        else if(line.X==-99999){
            IX = X;
            IY =line.M*IX+line.IP;
        }
        else if(X==X){
            System.out.println("Point of intersection: infinity,infinity ");
            return ;
        }
        else{
            System.out.println("Point of intersection: null");
            return ;
        }
        
        /*line.setLocation(IX,IY);
        return point;*/            
            System.out.printf("Point of intersection: %.2f,%.2f\n",IX,IY);
        //}
    }
}
