/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_2;

/**
 *
 * @author ADMIN
 */
public class Lab5_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Line l1 = new Line(-2,1,1,-2);
        Line l2 = new Line(-6,-2,-2,0);
        System.out.println("Are the two lines equals?: "+l2.equals(l1));
        System.out.println("Are the two lines parallel?: "+l2.isParallel(l1));
        System.out.println("Do the two lines intersect?: "+l2.isIntersect(l1));
        l2.getIntersectionPoint(l1);
    }
    
}
