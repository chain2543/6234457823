/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_2;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author acer
 */
public class Game {
  private int player,computer;         
  
public void play(){           
    while(true){
        Scanner choose = new Scanner(System.in);
        System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
        int play = choose.nextInt();
        if(play==0 || play==1 || play==2){
            switch (play){
                case 0:
                    System.out.println("You enter: ROCK");
                    break;
                case 1:
                    System.out.println("You enter: PAPER");
                    break;
                default:
                    System.out.println("You enter: SCISSORS");
                    break;
            }
            Random com = new Random();
            int bot = com.nextInt(3);
            switch (bot) {
                case 0:
                    System.out.println("Computer: ROCK");
                    break;
                case 1:
                    System.out.println("Computer: PAPER");
                    break;
                default:
                    System.out.println("Computer: SCISSORS");
                    break;
            }
            if(play==bot){System.out.println("It's a tie.");}
            else if(play==0&&bot==1){System.out.println("You lose!");computer++;}
            else if(play==0&&bot==2){System.out.println("You win!");player++;}
            else if(play==1&&bot==0){System.out.println("You win!");player++;}
            else if(play==1&&bot==2){System.out.println("You lose!");computer++;}
            else if(play==2&&bot==0){System.out.println("You lose!");computer++;}
            else if(play==2&&bot==1){System.out.println("You win!");player++;}                                                   
            if(player-computer==2||computer-player==2){break;}           
        }
    }
    if(player>computer){
        System.out.println("Congrats! You win.");
        System.out.println("User Score: "+player);
        System.out.println("Computer score: "+computer);
    }
    else if(player<computer){
        System.out.println("Too bad! You lose.");
        System.out.println("User Score: "+player);
        System.out.println("Computer score: "+computer);
    } 
}
}
       
       
       
       
       
    

