/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ADMIN
 */
public class NumericQuestion extends Question{
    public NumericQuestion() {
        super();
    }
    
    public NumericQuestion(String question) {
        super(question);
    }
    
    @Override
    public boolean checkAnswer(String response) {
        double diff = Double.parseDouble(response) - Double.parseDouble(this.getAnswer());
        if (diff > 0.01) {
            return false;
        }
        return true;
    }
}
