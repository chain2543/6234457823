/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.ArrayList;
/**
 *
 * @author ADMIN
 */
public class ChoiceQuestion extends Question{
    private ArrayList<String> choices;
    
    public ChoiceQuestion() {
        super();
    }
    
    public ChoiceQuestion(String question) {
        super(question);
        this.choices = new ArrayList<String>();
    }
    
    public void addChoice(String choice, boolean correct) {
        this.choices.add(choice);
        if (correct) {this.setAnswer(this.choices.size()+"");}
    }
    
    @Override
    public void display() {
        System.out.println(this.getText());
        int n = 1;
        for (String choice : this.choices) {
            System.out.printf("%d: %s", n, choice);
            System.out.println();
            n++;
        }
    }
    
    @Override
    public boolean checkAnswer(String response) {
        if (response.equals(this.getAnswer())) {
            return true;
        }
        return false;
    }
}
