/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ADMIN
 */
public class Question {
    private String text;
    private String answer;
    public Question(){}
    Question(String q){
        text = q;
    }
    public void setText(String q) {
        text = q;
    }
    public String getText() {
        return text;
    }
    public void setAnswer(String a) {
        answer = a;
    }
    public String getAnswer() {
        return answer;
    }
    public boolean checkAnswer(String response) {
        return response.equals(answer);
    }
    public void display() {
        System.out.println(text);
    }
}
