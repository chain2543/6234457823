/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;

/**
 *
 * @author usci
 */
public class Lab7_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Purse p1 = new Purse();
        Purse p2 = new Purse();
        Purse p3 = new Purse();
        Purse p4 = new Purse();
        Purse p5 = new Purse();
        p1.addCoin("Quarter");p1.addCoin("Dime");
        p1.addCoin("Nickel");p1.addCoin("Dime");
        p2.addCoin("Nickel");p2.addCoin("Dime");
        p2.addCoin("Dime");p2.addCoin("Quarter");
        p3.addCoin("Dime");
        p4.addCoin("Quarter");
        p5.addCoin("Nickel");p5.addCoin("Dime");
        p5.addCoin("Dime");p5.addCoin("Quarter");
        System.out.println(p1.toString());
        System.out.println(p5.reverse());
        p4.transfer(p3);
        System.out.println(p4+" "+p3);
        System.out.println(p5.sameContents(p2));
        System.out.println(p1.sameContents(p2));
        System.out.println(p5.sameCoins(p2));
        System.out.println(p1.sameCoins(p2));
    }
    
}
