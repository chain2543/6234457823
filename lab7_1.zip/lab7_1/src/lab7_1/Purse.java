/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;
import java.util.ArrayList;
/**
 *
 * @author usci
 */
public class Purse {
    ArrayList<String> nc = new ArrayList<String>();

    public void addCoin(String coinName){
        nc.add(coinName);
    }
    public String toString(){
        return "Purse"+nc;
    }
    public ArrayList<String> reverse(){
        ArrayList<String> ncr = new ArrayList<String>();
        for (int i = nc.size()-1;i>=0; i--) {
            ncr.add(nc.get(i));
        }
        return ncr;
    }
    public void transfer(Purse other)  {
        for(int i=0;i<nc.size();i++){
            other.nc.add(nc.get(i));
        }
        nc.clear();
    }
    public boolean sameContents(Purse other){
        return nc == other.nc;
    }
    public boolean sameCoins(Purse other){
        if(nc.size()!=other.nc.size()){
            return false;
        }
        ArrayList<String> test1 = new ArrayList<String>();
        ArrayList<String> test2 = new ArrayList<String>();
        test1 = nc;
        test2 = other.nc;
        for(int i=0;i<test1.size();i++){
            for(int j=i+1;j<test1.size();j++){
                if(test1.get(i)==test1.get(j)){
                    test1.remove(i);
                    i--;
                }
            }
        }
        for(int i=0;i<test2.size();i++){
            for(int j=i+1;j<test2.size();j++){
                if(test2.get(i)==test2.get(j)){
                    test2.remove(i);
                    i--;
                }
            }
        }
        if(test1.size()!=test2.size()){
            return false;
        }
        int s1[] = {0,0,0,0,0,0,0,0,0,0};
        String s[] = new String[10];
        int s2[] = {0,0,0,0,0,0,0,0,0,0};
        //String s2[] = new String[10];
        //int same[] = {0,0,0,0,0,0,0,0,0};
        for(int i=0;i<test1.size();i++){
            s[i]=test1.get(i);
            for(int j=0;j<nc.size();j++){
                if(nc.get(j)==s[i]){
                    s1[i]++;
                }
                if(other.nc.get(j)==s[i]){
                    s2[i]++;
                }
            }
        }
        if(s1==s2){
            return true;
        }
        return false;
    }
}
