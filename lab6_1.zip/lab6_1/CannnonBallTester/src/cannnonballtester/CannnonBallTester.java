/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cannnonballtester;

/**
 *
 * @author usci
 */
public class CannnonBallTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        CannonBall ball = new CannonBall(100); //กำหนดความเร็วตั้งต้นให้ลูกกระสุนปืนใหญ่มีค่าเป็น 100 m/sec
        ball.simulatedFlight();
        System.out.println(ball.calculusFlight(ball.getSimulatedTime()));
    }
    
}
