/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cannnonballtester;
import java.text.DecimalFormat;
/**
 *
 * @author usci
 */
public class CannonBall {
    private double initV; //ความเร็วตั้งต้น
    private double simS = 0; //ระยะทางที่คำนวณได้จากวิธี simulation
    private double simT = 0; //เวลาที่ใช้ในวิธี simulation
    public static final double g = 9.81;
    private double s;
    CannonBall(double v0){
        initV = v0;
    }
    public void simulatedFlight(){
        double i=0;
        DecimalFormat df = new DecimalFormat();
        df.applyPattern("#.###");
        while(i<100){
        //i=i-1+0.1;
        //System.out.println(""+i+" "+simS+"\n");
        s = simS;
        simS = ((-0.5)*g*i*i)+(initV*i);
        if(s>simS){
            simS=s;
            simT=i-0.001;
            break;
        }
        if(i%2==1){
            System.out.println("Distance on "+i+" sec: "+df.format(simS));
        }
        else if(i%2==0 && i!=0){
            System.out.println("Distance on "+i+" sec: "+df.format(simS));
        }
        //System.out.println(""+i+" "+simS+"\n");
        i=i+0.001;
        i = Double.parseDouble(df.format(i));
        }       
        
    }
    public String calculusFlight(double t){
        DecimalFormat df = new DecimalFormat();
        df.applyPattern("#.###");
        return ("Final distance: "+df.format(simS)+" Total time: "+df.format(simT)+"\nDistance from calculus equation:"+df.format(getSimulatedDistance()));
        
        
    }
    public double getSimulatedTime(){
        return simT;
    }
    public double getSimulatedDistance(){
        return simS;
    }
}
