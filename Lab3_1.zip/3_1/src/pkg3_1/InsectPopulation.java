/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg3_1;

/**
 *
 * @author asus
 */
public class InsectPopulation {
    private double num;
    public InsectPopulation (double n){
        num = n;
    }
    public void breed(){
        num = num*2;
    }
    public void spray(){
        num = num*90/100;
    }
    public double getNumInsect(){        
        return num;
    }
}
