/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg3_1;

/**
 *
 * @author usci
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        InsectPopulation pop = new InsectPopulation(10);
        pop.breed();
        pop.spray();
        System.out.println("Number of insects: "+pop.getNumInsect());
        pop.breed();
        pop.spray();
        System.out.println("Number of insects: "+pop.getNumInsect());
        pop.breed();
        pop.spray();
        System.out.println("Number of insects: "+pop.getNumInsect());
        // TODO code application logic here
    }
    
}
class InsectPopulation {
    private double num;
    public InsectPopulation (double n){
        num = n;
    }
    public void breed(){
        num = num*2;
    }
    public void spray(){
        num = num*90/100;
    }
    public double getNumInsect(){        
        return num;
    }
}
