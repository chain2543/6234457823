/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ADMIN
 */
public abstract class Taylor {
    private static int k ;
    private static double x;
    Taylor(int k,double x){
        this.x = x;
        this.k=k;
    }
    public int factorial(int n){
        int ans=1;
        for(int i=1;i<=n;i++){
            ans = ans*i;
        }
        return ans;
    }
    public void setIter(int K){
        k = K;
    }
    public int getIter(){
        return k;
    }
    public void setValue(double X){
        x = X;
    }
    public double getValue(){
        return x;
    }
    public abstract void printValue();
    
    public abstract double getAprox();
}
